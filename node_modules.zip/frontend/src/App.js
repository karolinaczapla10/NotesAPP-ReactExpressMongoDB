import React, { useState } from 'react';
import './App.css';
import Notes from './components/Notes';
import Login from './components/Login/Login';
import Registration from './components/Registration/Registration';



function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [logUser, setlogUser] = useState('');

  const handleLogin = () => {
    setLoggedIn(true);
  };

  const handleLogout = () => {
    setLoggedIn(false);
  };

  return (
    <div className="App">
      {!loggedIn ? (
        <>
          <Login onLogin={handleLogin} 
          setlogUser={setlogUser} setLoggedIn={setLoggedIn}/>
          <Registration />
        </>
      ) : (
        <Notes onLogout={handleLogout} logUser={logUser} />
      )}
    </div>
  );
}

export default App;
