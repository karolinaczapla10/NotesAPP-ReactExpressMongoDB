import React, { useState } from 'react';
import axios from 'axios';

function Registration(props) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleRegistration = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post('http://localhost:3000/api/register', {
        username,
        password
      });

      // Jeśli rejestracja powiodła się, możesz wykonać odpowiednie akcje,
      // takie jak wyświetlenie komunikatu o sukcesie lub przekierowanie użytkownika
      console.log(response.data); // Przykładowa reakcja z serwera

      // Przekazanie informacji o rejestracji do komponentu nadrzędnego
      props.onRegistrationSuccess();
    } catch (error) {
      console.error(error);
      // Obsługa błędu rejestracji
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-inner">
        <form onSubmit={handleRegistration}>
          <h3>Sign Up</h3>

          <div className="mb-3">
            <label>Username</label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter username"
              onChange={handleUsernameChange}
            />
          </div>

          <div className="mb-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              onChange={handlePasswordChange}
            />
          </div>

          <div className="d-grid">
            <button type="submit" className="btn btn-primary">
              Register
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Registration;
