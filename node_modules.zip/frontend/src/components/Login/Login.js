import React, { useState } from 'react';
import axios from 'axios';
import App from '../../App.js'

function Login(props) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleLogin = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post('http://localhost:3000/api/login', {
        username,
        password
      });
      if(response.data){
        props.setlogUser(response.data.username);
        props.setLoggedIn(true);
        localStorage.setItem("username", username);
      }

      // Jeśli logowanie powiodło się, możesz wykonać odpowiednie akcje,
      // takie jak ustawienie flagi zalogowania, przechowanie tokena itp.
      console.log(response.data); // Przykładowa reakcja z serwera
      
    } catch (error) {
      console.error(error);
      // Obsługa błędu logowania
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-inner">
        <form onSubmit={handleLogin}>
          <h3>Sign In</h3>

          <div className="mb-3">
            <label>Username</label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter username"
              onChange={handleUsernameChange}
            />
          </div>

          <div className="mb-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              onChange={handlePasswordChange}
            />
          </div>



          <div className="d-grid">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}

export default Login;
