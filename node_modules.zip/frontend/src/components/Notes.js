import React, { useState } from 'react';
import './Notes.css';
import Note from './Notes/Note/Note';
import NewNote from './NewNote/NewNote';
import Modal from 'react-modal';
import EditNote from './EditNote/EditNote';
import axios from 'axios';

class Notes extends React.Component {


    constructor(props) {
      super(props);
      ///
      this.state = {
        notes: [],
       
  
        // edit note
        showEditModal: false,
        editNote: {},
        username: '',
      };
    }
//raz sie uruchomi gdy komponet zostanie
componentDidMount(){
    this.fetchNotes();
}


//LACZENIE SIE Z API ZACIAGANIE NOTATEK Z BACKENDU
async fetchNotes() {

      const res = await axios.get('http://localhost:3000/api/notes');
      const notes = res.data;
      this.setState({ notes });
  }
  

  async deleteNote(id) {
    console.log('usuwanie notatki ', id);
  
    try {
      await axios.delete(`http://localhost:3000/api/notes/` + id);
  
      const notes = [...this.state.notes]
                    .filter(note => note._id !== id);
      this.setState({ notes });
    } catch (error) {
      console.error('Błąd podczas usuwania notatki:', error);
    }
  }

    async addNote(note){
        const notes = [...this.state.notes];
        //dodawanie notatek na backend
        //note  - obiekt zawierajacy title body
        const res = await axios.post('http://localhost:3000/api/notes', note);
        const newNote = res.data;
        //dodanie notatek na froncie
        notes.push(newNote);
        this.setState({notes});
    }

    async editNote(note){
        //edit backend
        await axios.put('http://localhost:3000/api/notes/' + note._id, note);

        //edit front 
        const notes = [...this.state.notes];
        //znajdz index elementu ktorego element w tablicy = note.id
        const index = notes.findIndex(x => x._id === note._id)
        if(index >= 0){
            notes[index] = note;
            this.setState({notes});
        }
        this.toggleModal();
    }
//funckja do chowania modelu
    toggleModal() {
        this.setState({
          showEditModal: !this.state.showEditModal
        });
      }
    
      editNoteHandler(note) {
        this.toggleModal();
        //ustawienie notatki 
        this.setState({ editNote: note });
      }

      handleLogout = () => {
        // Wykonaj operacje wylogowania (np. wyczyszczenie tokena, zakończenie sesji itp.)
        // ...
    
        // Po zakończeniu operacji wylogowania, wywołaj funkcję przekazaną przez props onLogout
        this.props.onLogout();
      }
    
  
    render(){

        return(
            <div>
              <button onClick={this.handleLogout}>Wyloguj</button>
              
               <p>Moje notatki</p> 
               
               <NewNote
                onAdd={(note) => this.addNote(note)}
                username={this.state.username}
               />


                <Modal
                    isOpen={this.state.showEditModal}
                    contentLabel="Edytuj notatkę">
                        <EditNote
                        title={this.state.editNote.title}
                        body={this.state.editNote.body}
                        id={this.state.editNote._id}
                        onEdit={note => this.editNote(note)}/>
                        <button onClick={() => this.toggleModal()}>Anuluj</button>
                </Modal>

                {this.state.notes.map(note => (
                    <Note 
                    key={note._id}
                    title={note.title}
                    body = {note.body} 
                    id={note._id}
                    onEdit={(note) => this.editNoteHandler(note)}
                    onDelete={(id)=>this.deleteNote(id)}
                    
                    />
                ))}
            </div>
        );
    }
}
export default Notes;